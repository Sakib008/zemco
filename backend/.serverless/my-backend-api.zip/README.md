## API For the Restaurant

POST /restaurants – Add a restaurant

GET /restaurants – List all

GET /restaurants/:id – Single restaurant

GET /restaurants/search?name=xyz

GET /restaurants/cuisine/:type

PUT /restaurants/:id – Update address/rating

DELETE /restaurants/:id